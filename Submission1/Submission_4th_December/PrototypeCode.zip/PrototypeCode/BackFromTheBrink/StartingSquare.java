package BackFromTheBrink;

public class StartingSquare extends Square {

	public StartingSquare() {
		super();
		this.squareName = "Go";
	}
}
