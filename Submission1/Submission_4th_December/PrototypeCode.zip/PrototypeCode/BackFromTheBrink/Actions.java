package BackFromTheBrink;

public interface Actions {

	public void runAction(Square square, Player player);

	
}
