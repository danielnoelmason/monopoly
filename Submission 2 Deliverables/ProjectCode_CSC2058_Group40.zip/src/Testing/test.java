package Testing;

import Controller.Controller;

/**
 * 
 * Has a main method to run the game
 *
 */
public class test {

	/**
	 * Runs game
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Controller game = new Controller();
		game.runGame();
	}

}
