package Entities;

/**
 * @author danielmason
 * Square where nothing happens i.e start square
 *
 */
public class NullSquare extends Square {

	public NullSquare(String name) {
		super();
		this.squareName = name;
	}

}
